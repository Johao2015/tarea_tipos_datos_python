# Tarea: Tipos de Datos e Identificadores en Python

## Autor
Johao Flores

## Descripción del Proyecto
Este proyecto consiste en un programa desarrollado en Python que convierte una temperatura ingresada en grados Celsius a grados Fahrenheit.

## Tipos de Datos Utilizados
- String
- Float
- Boolean

## Herramientas Utilizadas
- Python
- PyCharm
- GitHub
