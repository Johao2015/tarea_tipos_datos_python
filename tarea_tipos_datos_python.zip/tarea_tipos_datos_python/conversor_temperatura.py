"""
Programa: Conversor de Temperatura
Descripción:
Este programa convierte una temperatura ingresada en grados Celsius
a grados Fahrenheit y muestra el resultado al usuario.
Autor: Johao Flores
"""

def convertir_celsius_a_fahrenheit(temperatura_celsius):
    temperatura_fahrenheit = (temperatura_celsius * 9 / 5) + 32
    return temperatura_fahrenheit

nombre_usuario = "Johao Flores"
temperatura_celsius = float(input("Ingrese la temperatura en grados Celsius: "))

conversion_realizada = True

resultado_fahrenheit = convertir_celsius_a_fahrenheit(temperatura_celsius)

if conversion_realizada:
    print(f"\nHola {nombre_usuario}")
    print(f"La temperatura de {temperatura_celsius} °C equivale a {resultado_fahrenheit} °F")
